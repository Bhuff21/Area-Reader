
package lab3a;

public class Lab3A {

    public static void main(String[] args) {
        
        if (args.length < 3){
            System.out.println("Error: not enough arguments");
            System.exit(0);
        }
        
        double NumberOne = Double.parseDouble(args[0]);
        char operator = args[1].charAt(0);
        double NumberTwo = Double.parseDouble(args[2]);
        double Result = 0;
        
        if (operator == '+'){
            Result = NumberOne + NumberTwo;
        }
        else if(operator == '-'){
            Result = NumberOne - NumberTwo;
        }
        else if(operator == '*'){
            Result = NumberOne * NumberTwo;
        }
        else if(operator == '/'){
             if(NumberTwo == 0){
                 
                 System.out.println("Error: Can not divide by 0");
                 System.exit(0);
             }
             
            Result = NumberOne / NumberTwo; 
        }
        System.out.println(NumberOne + " " + operator + " " + NumberTwo + " = " + Result);
    }
    
}
