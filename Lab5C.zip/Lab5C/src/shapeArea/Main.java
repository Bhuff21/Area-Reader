package shapeArea;

public class Main {

    public static void main(String[] args) {
        Circle circle = new Circle(2,3,5, 4.0);       
        Rectangle rectangle = new Rectangle(5,5,5, 4.0, 10.0);      
        Triangle triangle = new Triangle(2,1, 3, 4.0, 8.0);      
        System.out.println(circle.toString());  
        System.out.println(triangle.toString());
        System.out.println(rectangle.toString());
        System.out.printf("Area of circle :%.1f ", circle.area());
        System.out.println();
        System.out.printf("Area of Rectangle :%.1f ", rectangle.area());
        System.out.printf("\nArea of Triangle :%.1f ", triangle.area());
   }
}
