
package lab2a;
        
import java.util.Scanner;
        
public class Lab2a {

    public static void main(String[] args) {
      
        int smallestNumber = 101;
        int largestNumber = 0;
        int totalValue = 0;
        int currentNumber;
        
        System.out.println("Please enter 10 different numbers");
        Scanner input = new Scanner(System.in);
        
        
        for (int i = 0; i < 10; i++){
            currentNumber = input.nextInt();
            
            if (currentNumber > largestNumber){
                largestNumber = currentNumber;
            }
            if (currentNumber < smallestNumber) {
                smallestNumber = currentNumber;
            }
            totalValue += currentNumber;
           
        }
        double averageNumber = (totalValue/10);
        System.out.println("The smallest number is - " + smallestNumber);
        System.out.println("The largest number is - " + largestNumber);
        System.out.println("The average number is - " + averageNumber);
    }
   
    
}
